#!/usr/bin/env python
# coding: utf-8

# In[16]:


# importing packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns



# reading the csv file
df = pd.read_csv('movie dataset.csv')
df.head()


# In[4]:


# Finding all the Null values
df.isnull().sum()

#count zero values in budget, revenue and runtime
df_budget_count =  df.groupby('budget').count()['id']
df_revenue_count =  df.groupby('revenue').count()['id']
df_runtime_count =  df.groupby('runtime').count()['id']

##Observations:
##Budget and Revenue has lot nu ber of rows with 0 as their value dropping them is not a good choice so, I decided to keep them and replace 0 with Null values
##Duplicated rows should be dropped.
##Drop unnecessary columns homepage, tagline, imdb_id, overview,budget_adj, revenue_adj, keywords.
##Dropping rows with lesser null vaules - cast, director, and genres.
##Drop zero values rows of runtime as it has lesser zero values.

# drop columns that are not necessary

col = ['imdb_id', 'homepage', 'tagline', 'overview', 'budget_adj', 'revenue_adj', 'keywords']
df.drop(col, axis=1, inplace=True)
df.head(1)


# In[5]:


#replace zero values with null values in the budget and revenue column.
df['budget'] = df['budget'].replace(0, np.NaN)
df['revenue'] = df['revenue'].replace(0, np.NaN)
# see if nulls are added in budget and revenue columns
df.info()


# In[18]:


##Budget and Revenuecorelation
import matplotlib.pyplot as plt

df.plot(x='budget',y='revenue',kind='scatter', color = 'blue')
plt.title('Budget and Revenue correlation')
plt.show()


# In[ ]:




